<?php $__env->startSection('content'); ?>
      <div class="uk-container">

       <div class="uk-card uk-card-default uk-card-body">
            <form class="uk-form-horizontal uk-margin-large" method="post">

                    <?php echo e(csrf_field()); ?>


                    <h1>Edit Book</h1>


               <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Name</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="name" name="book_name" value="<?php echo e($book->book_name); ?>">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Count</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Count" name="count" value="<?php echo e($book->count); ?>">
                    </div>
                </div>
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Book Category</label>
                    <div class="uk-form-controls">
                        <select name="category" id="" class="uk-select">
                            <option value="CSE">CSE</option>
                            <option value="EEE">EEE</option>
                        </select>
                    </div>
                </div>


            <div class="uk-margin">
                <input class="uk-button uk-button-primary" type="submit" name="Submit" value="Submit">

              </div>

            </form>
        </div>
    
  </div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/book/edit.blade.php ENDPATH**/ ?>