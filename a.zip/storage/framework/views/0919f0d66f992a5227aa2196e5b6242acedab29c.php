<?php $__env->startSection('content'); ?>

<div class="uk-container">
  <a href="<?php echo e(route('book.add')); ?>"  class="uk-button uk-button-primary">Add Book</a>
    <table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Count</th>
             <th>Category</th>
              <th>Edit</th>
               <th>Delete</th>
        </tr>
    </thead>
    <tbody>

            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($book->id); ?></td>
            <td><?php echo e($book->book_name); ?></td>
            <td><?php echo e($book->count); ?></td>
             <td><?php echo e($book->category); ?></td>

            <td> <a href="<?php echo e(route('book.edit',$book->id)); ?>"  class="uk-button uk-button-primary">Edit</a> </td>
                        <td> <a href="<?php echo e(route('book.delete',$book->id)); ?>"  class="uk-button uk-button-primary">Delete</a> </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/book/index.blade.php ENDPATH**/ ?>