<?php $__env->startSection('content'); ?>

<div class="uk-container">
  <a href="<?php echo e(route('admin.add')); ?>"  class="uk-button uk-button-primary">Add Manager</a>
    <table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>username</th>
              <th>Edit</th>
               <th>Delete</th>
        </tr>
    </thead>
    <tbody>

            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($admin->id); ?></td>
            <td><?php echo e($admin->name); ?></td>
            <td><?php echo e($admin->username); ?></td>

            <td> <a href="<?php echo e(route('admin.edit',$admin->id)); ?>"  class="uk-button uk-button-primary">Edit</a> </td>
                        <td> <a href="<?php echo e(route('admin.delete',$admin->id)); ?>"  class="uk-button uk-button-primary">Delete</a> </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/manager/index.blade.php ENDPATH**/ ?>