<?php $__env->startSection('content'); ?>

<div class="uk-container">


	<article class="uk-comment">
    <header class="uk-comment-header uk-grid-medium uk-flex-middle" uk-grid>
      
        <div class="uk-width-expand">
            <h1>Profile:</h1>
            <h4 class="uk-comment-title uk-margin-remove"><a class="uk-link-reset" href="#">Hello <?php echo e(session('name')); ?> </a></h4>
           
        </div>
    </header>
   
</article>


<div class="uk-margin">

	</div>

	

	

	
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/admin/index.blade.php ENDPATH**/ ?>