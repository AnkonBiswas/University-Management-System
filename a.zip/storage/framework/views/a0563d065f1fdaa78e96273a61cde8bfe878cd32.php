<?php $__env->startSection('content'); ?>

<div class="uk-container">
	<form method="post"  enctype="multipart/form-data">
		                    <?php echo e(csrf_field()); ?>


		<input type="submit" name="submit" value="Confirm Course" class="uk-button uk-button-primary">
    <table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>Course Id</th>
            <th>Id</th>
            <th>Course Name</th>
             <th>Section</th>
              <th>Seat</th>
           
              <th>Enroll</th>
        </tr>
    </thead>
    <tbody>
    	

            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          

<?php if($course->preq != null): ?>

  <?php $__currentLoopData = $coursestudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


  <?php if($course->preq == $scourse->course_id): ?>





        <tr>
            <td><?php echo e($course->c_id); ?></td>
            <td><?php echo e($course->id); ?></td>
            <td><?php echo e($course->course_name); ?></td>
             <td>
<?php echo e($course->section); ?>

            </td>
            <td>
<?php echo e($course->seats); ?>

            </td>

            <td> <input class="uk-checkbox" type="checkbox" value="<?php echo e($course->id); ?>" name="course[]"> Enroll </td>
             
             
              
         

        </tr>
        
 <?php endif; ?>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         <?php else: ?>


            <tr>
            <td><?php echo e($course->c_id); ?></td>
            <td><?php echo e($course->id); ?></td>
            <td><?php echo e($course->course_name); ?></td>
             <td>
<?php echo e($course->section); ?>

            </td>
            <td>
<?php echo e($course->seats); ?>

            </td>

              <td> <input class="uk-checkbox" type="checkbox" value="<?php echo e($course->id); ?>" name="course[]"> Enroll </td>

        </tr>

           <?php endif; ?>



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </tbody>
</table>
</form>
</div>

  


    


        


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/student/course.blade.php ENDPATH**/ ?>