<?php $__env->startSection('content'); ?>

<div class="uk-container">
  <a href="<?php echo e(route('course.add')); ?>"  class="uk-button uk-button-primary">Add Course</a>
    <table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>Course Id</th>
            <th>Id</th>
            <th>Course Name</th>
             <th>Section</th>
              <th>Seat</th>
              <th>Category</th>
              <th>Preq</th>
              <th>Status</th>
              <th>Edit</th>
               <th>Delete</th>
        </tr>
    </thead>
    <tbody>

            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($course->c_id); ?></td>
            <td><?php echo e($course->id); ?></td>
            <td><?php echo e($course->course_name); ?></td>
             <td>
<?php echo e($course->section); ?>

            </td>
            <td>
<?php echo e($course->seats); ?>

            </td>
              <td>
<?php echo e($course->category); ?>

            </td>
              <td>
<?php echo e($course->preq); ?>

            </td>
               <td>
<?php echo e($course->status); ?>

            </td>
            <td> <a href="<?php echo e(route('course.edit',$course->c_id)); ?>"  class="uk-button uk-button-primary">Edit</a> </td>
                        <td> <a href="<?php echo e(route('course.delete',$course->c_id)); ?>"  class="uk-button uk-button-primary">Delete</a> </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/course/index.blade.php ENDPATH**/ ?>