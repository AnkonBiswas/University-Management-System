<?php $__env->startSection('content'); ?>
      <div class="uk-container">

       <div class="uk-card uk-card-default uk-card-body">
            <form class="uk-form-horizontal uk-margin-large" method="post">

                    <?php echo e(csrf_field()); ?>


                    <h1>Add Course</h1>


               <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Course Id</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Id" name="id">
                    </div>
                </div>
                  <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Course Name</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Course Name" name="course_name">
                    </div>
                </div>

                 <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Course Section</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Section" name="section">
                    </div>
                </div>

                   <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Course Seats</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Seats" name="seats">
                    </div>
                </div>

                 <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Course Category</label>
                    <div class="uk-form-controls">
                        <select name="category" id="" class="uk-select">
                            <option value="CSE">CSE</option>
                            <option value="EEE">EEE</option>
                        </select>
                    </div>
                </div>

                

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Course PREQ</label>
                    <div class="uk-form-controls">
                       <select name="preq" id="" class="uk-select">
                         <option value="">None</option>
                         <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Status</label>
                    <div class="uk-form-controls">
                       <select name="status" id="" class="uk-select">
                            <option value="1">Enable</option>
                            <option value="0">Disable</option>
                        </select>
                    </div>
                </div>



               

            <div class="uk-margin">
                <input class="uk-button uk-button-primary" type="submit" name="Submit" value="Submit">

              </div>

            </form>
        </div>
    
  </div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/course/add.blade.php ENDPATH**/ ?>