 <!DOCTYPE html>
<html>
    <head>
        <title>Title</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="/uikit/css/uikit.min.css" />
                <script src="/js/jquery-3.4.1.js"></script>

        <script src="/uikit/js/uikit.min.js"></script>
        <script src="/uikit/js/uikit-icons.min.js"></script>
        <style type="text/css">
        	.uk-margin-remove {
    margin: 0!important;
    padding: 34px;
}
        </style>
    </head>
    <body>
    	<div class="uk-container">

    	<nav class="uk-navbar-container" uk-navbar>
		    <div class="uk-navbar-left">

		        <ul class="uk-navbar-nav">
		            <li class="uk-active"><a href="<?php echo e(route('admin.index')); ?>">Home</a></li>
		            <li>
		            	<a href="<?php echo e(route('student.list')); ?>">Student</a>
		                
		            </li>
                   <li>
                        <a href="<?php echo e(route('faculty.list')); ?>">Faculty</a>
                        
                    </li>
                     <li>
                        <a href="<?php echo e(route('course.list')); ?>">Course</a>
                        
                    </li>
                      <li>
                        <a href="<?php echo e(route('book.list')); ?>">Books</a>
                        
                    </li>
                     <li>
                        <a href="<?php echo e(route('admin.list')); ?>">Manager</a>
                        
                    </li>
                     <li>
                        <a href="<?php echo e(route('post.index')); ?>">Notice Board</a>
                        
                    </li>
		            <li><a href="<?php echo e(route('logout.index')); ?>">Logout</a></li>
		        </ul>

		    </div>
        </nav>


                



<div class="uk-alert-danger" uk-alert>
    <a class="uk-alert-close" uk-close></a>
    <p><?php echo e(session('msg')); ?></p>
</div>
         <?php echo $__env->yieldContent('content'); ?>



</div>
    </body>
</html>

<?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/admin/main.blade.php ENDPATH**/ ?>