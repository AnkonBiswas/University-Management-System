<?php $__env->startSection('content'); ?>

<div class="uk-container">
  <a href="<?php echo e(route('post.add')); ?>"  class="uk-button uk-button-primary">Add Post</a>
    <table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Content</th>
             
    </thead>
    <tbody>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->name); ?></td>
            <td><?php echo e($post->content); ?></td>

            

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/post/index.blade.php ENDPATH**/ ?>