<?php $__env->startSection('content'); ?>

<div class="uk-container">
   
        <div class="uk-card uk-card-default uk-card-body">
            <form class="uk-form-horizontal uk-margin-large" method="post">

                    <?php echo e(csrf_field()); ?>


                    <h1>Edit Faculty : <?php echo e($user->full_name); ?></h1>


               <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Name</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="name" name="full_name" value="<?php echo e($user->full_name); ?>">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Username</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Username" name="username" value="<?php echo e($user->username); ?>">
                    </div>
                </div>
                  <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Password</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="password" placeholder="Password" name="password" value="<?php echo e($user->password); ?>">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Gender</label>
                    <div class="uk-form-controls">
                        <select class="uk-select" name="gender">

                          <?php if($user->gender == 'male'): ?>

 <option value="male" selected="">Male</option>

 <option value="female">Female</option>

  <?php else: ?>

      
 <option value="male">Male</option>

 <option value="female" selected="">Female</option>
                    
       <?php endif; ?>
                         
                        </select>
                    </div>
                </div>


                 <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-text">Contact</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-horizontal-text" type="text" placeholder="Contact" name="contact" value="<?php echo e($user->contact); ?>">
                    </div>
                </div>



            <div class="uk-margin">
                <input class="uk-button uk-button-primary" type="submit" name="Submit" value="Submit">

              </div>

            </form>
        </div>
    
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\O.S.S\Desktop\ums\University-Management-System\resources\views/faculty/edit.blade.php ENDPATH**/ ?>