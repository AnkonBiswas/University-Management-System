<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Coursestudents extends Model
{
    //

     public $timestamps = false;

    protected $primaryKey = "cs_id";
}
