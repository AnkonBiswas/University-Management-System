<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    //
     protected $primaryKey = "c_id";
    public $timestamps = false;
}
